# CampusBrain UI handoff

## Visual system

- **Canvas:** `--bg` charcoal; light mode swaps the canvas to soft cream.
- **Surfaces:** `--soft` cream list rows, `--sage` olive panels, `--cream` text/light surface.
- **Action:** `--accent` burnt orange for primary actions, selected dates, deadlines, and the sparkle.
- **Status:** `--blue`, `--green`, and charcoal pills for informational, success, and completed states.
- **Typography:** Bricolage Grotesque / General Sans for expressive headings and UI; monospace for dates, metadata, and badges.
- **Geometry:** `--radius-xl` nested panels, `--radius-lg` cards, `--radius-md` rows, and pill controls.
- **Motion:** short color/transform transitions only; no gradients or heavy shadow layers.

## Screens and purpose

| Screen | Purpose | Primary actions |
|---|---|---|
| Welcome | Explain the product and prototype boundary | Log in, create account, enter demo workspace |
| Login | Validate email/password presentation | Show password, recover password, sign up, enter dashboard |
| Sign up | Validate name, email, and matching passwords | Create prototype profile |
| Forgot password | Model recovery confirmation honestly | Validate email; show local confirmation without sending mail |
| Dashboard / Home | Surface files, notices, attendance, and deadlines | Switch tabs, open calendar, upload, open chat/settings |
| Month | Inspect October 2026 deadlines and adjacent months | Navigate month, select dates, read details |
| Attendance | Review weekly grid and subject warnings | Return home; inspect present/absent/no-class states |
| Chat | Demonstrate the conversation UI | Suggested prompts, submit text, toggle mic state |
| Settings | Expose preferences and appearance | Toggle theme, return, log out to welcome |

## State transitions

- `welcome → login | signup | demo dashboard`
- `login → forgot | signup | dashboard` after client-side validation
- `signup → dashboard` after client-side validation
- `forgot → recovery confirmation` without a network request
- `dashboard ↔ month | attendance | chat | settings`
- Desktop jump controls route `Attendance` and `Calendar` to their dashboard sections (not hidden mobile sheets).
- `files/notices` tabs are local view switches on both mobile and desktop.
- Upload uses the native file picker, rejects files above 10 MB, and reports that successful selection is local demo state only.
- Theme is persisted under `campusbrain-theme`; demo access is persisted under `campusbrain-demo-auth`.
- Chat responses are explicitly demo copy; no AI service or backend is connected.

## Implementation notes

The prototype remains a single self-contained HTML file. The next scaffold can split the auth views, app shell, calendar model, and chat shell into routes/components while retaining the token names and state contracts above.

## Final v4 bug-fix pass (pre-scaffold)

### Repaired in this pass

- Desktop `Attendance` and `Calendar` controls now keep users on desktop and jump to `#desktopAttendanceSection` / `#desktopCalendarSection`.
- Desktop and mobile view switching now share one route guard (`dashboard` maps to `home` on mobile).
- Desktop calendar dates are interactive `<button>` elements with `aria-label` and `aria-pressed`, and selection updates details for both desktop/mobile calendars.
- Month navigation now preserves day-of-month where possible instead of forcing day `1`.
- Upload messaging now explicitly states: file is selected in local demo state only, not uploaded or persistently stored.
- Date copy was aligned to October 2026 references (`Sun 18 Oct 2026`, `Mon 19`, `Wed 21`, `Fri 23`) across reminders/chat/calendar event data.
- Mobile bottom navigation now sets `aria-current` for the active destination.
- Added desktop-width guard styles at `<=1280px` to prevent overflow while preserving the established layout.

### Still intentionally simulated / not implemented

- Authentication is UI-only (no real account, session API, or backend identity provider).
- Chat is UI-only (no AI API call).
- File upload is picker + validation only (no persistent storage backend).

### Quick interaction checklist for dev scaffolding

1. Auth: Welcome → Login/Sign up → Dashboard; Forgot password shows local confirmation state.
2. Desktop: Attendance/Calendar jump controls keep desktop dashboard active.
3. Calendar: Date select + month prev/next update note text and selected state.
4. Library tabs: Files/Notices switch on both mobile and desktop.
5. Upload: valid file (<10 MB) shows local-only success message; >10 MB shows error.
6. Theme: toggle persists after refresh via `campusbrain-theme`.

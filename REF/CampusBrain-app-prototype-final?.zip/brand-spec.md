# CampusBrain brand spec

## Tokens

- `--bg`: `oklch(15.4% 0.01 120)` — dark charcoal canvas
- `--surface`: `oklch(98.5% 0.03 95)` — soft cream elevated rows
- `--fg`: `oklch(91% 0.04 100)` — primary cream text
- `--muted`: `oklch(62% 0.04 100)` — muted sage text
- `--border`: `oklch(80% 0.04 100)` — sage panel edge / divider
- `--accent`: `oklch(65% 0.17 43)` — hot orange action color

## Typography

- Display: `Bricolage Grotesque`, `General Sans`, `Arial`, sans-serif
- Body: `General Sans`, `Avenir Next`, `Segoe UI`, sans-serif
- Mono: `ui-monospace`, `SFMono-Regular`, `Menlo`, monospace

## Observed rules

1. Warm, bold editorial-modern language with charcoal screens and cream/sage surfaces.
2. Large rounded panels nest flat color layers; depth comes from color, not heavy shadows.
3. Orange is reserved for primary actions, selected states, deadlines, and the sparkle mascot.
4. UI labels stay compact and lowercase-friendly while headings use bold, tight title case.
5. Hatched empty states, concentric arcs, tiny status pills, and right-edge chevrons create the signature rhythm.

CampusBrain is a friendly, high-contrast campus operating system: calm cream content sits inside an expressive charcoal frame, with orange reserved for moments that need action.
